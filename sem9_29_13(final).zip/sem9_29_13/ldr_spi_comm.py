import spidev
import time

spi = spidev.SpiDev(0,0)
spi.open(0,0)
spi.max_speed_hz=9600
while 1:
# spi.writebytes([0x01])
 #spi.writebytes([0x4, 0x06])
 y=spi.readbytes(2)
 print(y)
 time.sleep(0.5)