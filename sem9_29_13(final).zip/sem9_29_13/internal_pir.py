import RPi.GPIO as gpio
import time
import datetime
import paho.mqtt.client as mqtt
broker_url = "broker.hivemq.com"
broker_port=1883

def on_connect(client, userdata, flags, rc):
 print("connected with rc: {rc}")

def on_message(client, userdata, message):
 print("message: "+ message.payload.decode())

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect(broker_url, broker_port)
client.subscribe("coding_mandali", qos=0)

gpio.setwarnings(False)
gpio.setmode(gpio.BOARD)

gpio.setup(35, gpio.OUT)
gpio.setup(37, gpio.IN)

while(True):
 myin = gpio.input(37)
 if myin == True:
  dt = str(datetime.datetime.now())
  client.publish(topic="coding_mandali", payload="motion detected"+ dt, qos=1, retain=False)
  time.sleep(1)
  gpio.output(35, True)
  time.sleep(0.5)
  gpio.output(35, False)
  time.sleep(0.5)
