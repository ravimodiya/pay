import paho.mqtt.client as mqtt
import spidev
import time
import sqlite3
import datetime

broker = "broker.hivemq.com"
port = 1883
topic = "testingserver"
client = mqtt.Client()
client.connect(broker,port)

spi = spidev.SpiDev(0,0)
spi.open(0,0)
msg=0xAA
spi.max_speed_hz=9600
db_conn = sqlite3.connect("internal_ldr.db")
query="""create table if not exists sensors_data(id integer primary key autoincrement, value integer, timestamp varchar(100))"""
cursor=db_conn.cursor()
cursor.execute(query)
while 1:
 y=spi.readbytes(1)
 if y[0]>0:
  client.publish(topic=topic,payload=y[0],qos=0,retain=False)
  insert="""insert into sensors_data(value, timestamp) values (?,?)"""
  cursor.execute(insert, (y[0], str(datetime.datetime.now())))
  db_conn.commit()
  cursor.execute("select * from sensors_data")
  data=cursor.fetchall()
  print(data)
db_conn.close()

