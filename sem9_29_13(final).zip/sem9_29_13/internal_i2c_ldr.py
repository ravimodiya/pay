from smbus import SMBus
import sqlite3
import time
addr=0x8
bus=SMBus(1)
db_conn = sqlite3.connect("ldr_i2c.db")
query = """create table if not exists lrd_i2c(id integer primary key autoincrement, value integer, timestamp varchar(100))"""
cursor=db_conn.cursor()
while True:
 result = bus.read_byte_data(addr, 0x1)
 print(result)
 time.sleep(1)
