import RPi.GPIO as GPIO
import time
#GPIO.cleanup()
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(3,GPIO.OUT)
GPIO.setup(18,GPIO.IN)
while True:
 myin = GPIO.input(18)
 if myin == True:
  print("Motion detected")
  time.sleep(1);
  GPIO.output(3,True)
  time.sleep(0.5);
  GPIO.output(3,False)
  time.sleep(0.5)
#GPIO.cleanup()
