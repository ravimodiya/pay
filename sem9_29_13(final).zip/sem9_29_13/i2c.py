from smbus import SMBus
import time

addr=0x8
bus=SMBus(1)
numb=1
#print("Enter 1 for on and 0 for off")
while numb==1:
#bus.write_i2c_block_data(addr,0x00,[65,66,67,68,69,70])
# ledstate=input(">>>>")
# if ledstate=="1":
#  bus.write_byte(addr, 0x1)
  y=bus.read_byte_data(addr,0x1)
  print(y)
  time.sleep(0.5)
# elif ledstate=="0":
#  bus.write_byte(addr, 0x0)
# else:
#  numb=0

