from smbus import SMBus
bus = SMBus(1)
addr = 0x8

num = 1
ledstate = ""
print("Enter 1 to on led and 0 to off: ")
while num == 1:
 res = bus.read_byte_data(addr,0x02)
 print(res)
 if res:
  print("Arduino is connected.")
 ledstate = input(">>")
 if ledstate == "1":
  bus.write_byte(addr,0x1)
 elif ledstate == "0":
  bus.write_byte(addr,0x00)
 else:
  num = 0
