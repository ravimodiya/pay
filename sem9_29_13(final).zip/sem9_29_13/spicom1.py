import spidev
import time

spi = spidev.SpiDev(0,0)
spi.open(0,0)
spi.max_speed_hz = 9600

while True:
 spi.writebytes([0x04,0x05])
 result = spi.readbytes(1)
 print(chr(result[0]))
 time.sleep(0.5)
