import RPi.GPIO as io
import time
io.setwarnings(False)
io.setmode(io.BOARD)
io.setup(8,io.IN)
io.setup(3,io.OUT)
while True:
 if(io.input(8)==True):
  print("Obstacle detected")
  time.sleep(0.5)
  io.output(3, True)
 else:
  print("Obstacle not detected")
  io.output(3, False)
 
